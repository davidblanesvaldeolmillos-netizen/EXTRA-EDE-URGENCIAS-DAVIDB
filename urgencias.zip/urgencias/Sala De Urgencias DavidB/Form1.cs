﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Sala_De_Urgencias_DavidB.Form1;

namespace Sala_De_Urgencias_DavidB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //EJERCICIO 1

        public class Paciente
        {
            private string nombre;
            private int edad;
            private string prioridad;
            private int numcamilla;


            public Paciente(string nombre, int edad, string prioridad, int numcamilla)
            {
                this.nombre = nombre;
                this.edad = edad;
                this.prioridad = prioridad;
                this.numcamilla = numcamilla;
            }

            public string getNombre()
            {
                return nombre;
            }
            public int getEdad()
            {
                return edad;
            }
            public string getPrioridad()
            {
                return prioridad;
            }
            public int getNumCamilla()
            {
                return numcamilla;
            }

            public override string ToString()
            {
                return $"Nombre: {nombre}, Edad: {edad}, Prioridad: {prioridad}, Número de Camilla: {numcamilla}";

            }


            //EJERCICIO 2

            internal class program
            {
                static void Main(string[] args)
                {
                    List<Paciente> lista = new List<Paciente>();
                    lista.Add(new Paciente("Juan", 30, "rojo (crítico)", 1));
                    lista.Add(new Paciente("Maria", 25, "naranja (medio)", 2));
                    lista.Add(new Paciente("Pedro", 40, "verde (bajo)", 3));
                    lista.Add(new Paciente("Damián", 40, "rojo (crítico)", 3));
                    foreach (Paciente paciente in lista)
                    {
                        Console.WriteLine("Todos los pacientes: ");
                        foreach (Paciente p in lista)
                        {
                            Console.WriteLine(p.ToString());
                        }

                        Console.WriteLine("\n Pacientes con prioridad 'Alta',");
                        
                        foreach (Paciente p in lista)
                        {
                            if (p.Contains() == "Alta")
                            {
                                Console.WriteLine(p.ToString());
                            }
                        }
                        Console.WriteLine("\n Pacientes con prioridad 'Baja', ");
                        Console.WriteLine("\n Pacientes con prioridad 'Media', ");

                        string ruta = "C:\\Users\\David\\Desktop\\Pacientes.txt";
                        guardarPacientes(lista, ruta);
                        Console.WriteLine($"\n Pacientes guardados en el archivo {ruta}");
                    }
                }
                    
                        public static void guardarPacientes(List<Paciente> lista, string ruta)
                {
                    using (StreamWriter writer = new StreamWriter(ruta))
                    {
                        foreach (Paciente paciente in lista)
                        {
                            writer.WriteLine(paciente.ToString());
                        }
                        Console.ReadLine();
                    }
                }
            }

            private string Contains()
            {
                throw new NotImplementedException();
            }
        }

                private static void guardarPacientes(List<Paciente> lista, string ruta)
                {
                    throw new NotImplementedException();
                }
        //PARTE VISUAL DE LA CAJA
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }

            
        }









        









